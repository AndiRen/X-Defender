Pixel Noir Font Family
Font designed and created by Mirz (Michelle Lehmann)
=====================================

This font includes the main font and 4 variations.

Included in this package are the following fonts: 

* Pixel Noir
* Pixel Noir Caps
* Pixel Noir Skinny
* Pixel Noir Skinny Caps
* Pixel Noir Skinny Short

These fonts are best used at 6pt (8px) in most graphic programs.

This font may be used for personal and commercial use. Commercial 
use is restricted to incorporation in a project or design. You may not 
profit from direct sale/distribution of this font.  Please see my TOS 
page at http://scriptmonkeys.us/monkeys/2010/05/08/graphics-pixel-font-use-license/
for more details. 

Note that this font MAY be distributed on other websites, with the 
requirement that it be offered for free, and that all of the files and this 
Readme remain in-tact.
 
More pixel fonts from Mirz can be found at:
http://www.scriptmonkeys.us
http://mirz123.deviantart.com